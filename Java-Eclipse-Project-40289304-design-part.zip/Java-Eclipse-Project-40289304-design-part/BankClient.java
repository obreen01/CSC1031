package CSC1031Coursework;

public class BankClient extends Profile {

	private int clientID;
	private BankAccount[] accounts = new BankAccount[5];

	/*
	 * sets the ID of a client
	 * @param newID - a client's unique identifier
	 */
	public void setClientID(int newID) {
		this.clientID = newID;
	}

	/*
	 * sets a bank account object into the accounts array
	 * the for loop checks if a client has less than five accounts and if so creates a new one
	 * @param newAccount - a new account for the client
	 */
	public void setBankAccount(BankAccount newAccount) {
		for(int index = 0; index < 5; index++){
			if(accounts[index] == null) {
				newAccount.setId(index);
				newAccount.setBalance(1000);
				accounts[index] = newAccount;
			}
			else {
				System.out.println("Error, too many bank accounts.");
			}
		}
	}

	/*
	 * returns an array of bank accounts that a client has
	 * @return
	 */
	public BankAccount[] getBankAccounts() {
		return this.accounts;
	}

	/*
	 *returns a client's ID
	 *@return
	 */
	public int getClientID() {
		return this.clientID;
	}

}

package CSC1031Coursework;

public class BankAccount {
	
	private int bankAccountId;
	private double balance;
	
	/*
	 * sets the ID of the bank account
	 * @param id - the unique identifier of a bank account
	 */
	public void setId(int id) {
		this.bankAccountId = id;
	}
	
	/*
	 * sets the balance of the bank account
	 * @param newBalance - the balance of the account
	 */
	public void setBalance(double newBalance) {
		this.balance = newBalance;
	}
	
	/*
	 * returns the ID of the bank account
	 * @return
	 */
	public int getBankAccountId() {
		return this.bankAccountId;
	}
	
	/*
	 * returns the balance of the bank account
	 * @return
	 */
	public double getBalance() {
		return this.balance;
	}
}

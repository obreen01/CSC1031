package CSC1031Coursework;

public class Profile {
	
	private String firstName;
	private String lastName;
	private String address;
	private int age = -1;
	
	/*
	 * sets the first name of a client
	 * @param fName - a client's first name
	 */
	public void setFirstName(String fName) {
		this.firstName = fName;
	}
	
	/*
	 * sets the last name of a client
	 * @param lName - a client's last name
	 */
	public void setLastName(String lName) {
		this.lastName = lName;
	}
	
	/*
	 * sets the age of a client
	 * @param age - a client's age
	 */
	public void setAge(int age) {
		this.age = age;
	}
	
	/*
	 * sets the client's address
	 * @param newAddress - the client's address
	 */
	public void setAddress(String newAddress) {
		this.address = newAddress;
	}
	
	/*
	 * returns the full name of a client - first name concatenated with last name
	 * @return
	 */
	public String getFullName() {
		return this.firstName + " " + this.lastName;
	}
	
	/*
	 * returns the first name of a client
	 * @return
	 */
	public String getFirstName() {
		return this.firstName;
	}
	
	/*
	 * returns the last name of a client
	 * @return
	 */
	public String getLastName() {
		return this.lastName;
	}
	
	/*
	 * returns the address of a client
	 * @return
	 */
	public String getAddress() {
		return this.address;
	}
	
	/*
	 * returns the age of a client
	 * @return
	 */
	public int getAge() {
		return this.age;
	}
	
}

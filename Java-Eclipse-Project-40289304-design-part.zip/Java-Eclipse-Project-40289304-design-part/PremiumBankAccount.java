package CSC1031Coursework;

public class PremiumBankAccount extends BankAccount{
	
	private float fee = 5;
	private double cashback = 10;

	
	/*
	 * returns the fee for a premium account
	 * @return
	 */
	
	public float getFee() {
		return this.fee;
	}
	
	/*
	 * returns the cash-back
	 * @return
	 */
	
	public double getCashback() {
		return this.cashback;
	}
	
}

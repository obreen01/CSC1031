package CSC1031Coursework;

import java.util.Scanner;

public class UserInterface {
	
	private final int MAX_NUMBER_OF_CLIENTS = 1000;
	private BankClient[] clients = new BankClient[MAX_NUMBER_OF_CLIENTS];
	Scanner input = new Scanner(System.in);
	BankClient client = new BankClient();
	BankAccount[] accounts = new BankAccount[5];
	
	
	public static void main(String[] args) {
		UserInterface user = new UserInterface();
		user.batchRegistration();
		user.presentManagementOptions();
		user.moneyTransfer();
	}
	
	//Anthony - use case 1 - batch registration of bank clients
	public void batchRegistration() {
		// this loop creates a client, sets an id and adds it to the clients array
		for(int i = 0; i<1000 ; i++) {
			BankClient newClient = new BankClient();
			newClient.setClientID(i);
			clients[i] = newClient;
		}
	}
	
	//Anthony - use case 2 - presenting management options to the user
	public void presentManagementOptions() {
		System.out.println("Please Enter Your ID: ");
		int id = input.nextInt();
		boolean idExists = false;
		if(id < 0) {
			System.out.println("Error!");
		} else {
			if(id >=0 && id <=1000) {
				for(int i = 0; i < clients.length; i++) {
					int idCheck = clients[i].getClientID();
					if(id == idCheck) {
						idExists = true;
						client = clients[i];
					} 
				}
			}
			if(idExists = false) {
				System.out.println("Error!");
			} else {
				System.out.println("A. Create the profile of a bank-client");
				System.out.println("B. Update the profile of a bank-client");
				System.out.println("C. Create a bank account");
				System.out.println("D. Delete a bank account");
				System.out.println("E. Money transfer");
				System.out.println("F. Printing the profile of a bank client");
				System.out.println("G. Printing the bank accounts of a bank client");
				System.out.println("H. Exit");
				System.out.println("Please enter your choice: ");
				String choice = input.nextLine();
				switch(choice) {
				case "A":
					createBankClientProfile();
					break;
				case "B":
					updateBankClientProfile();
					break;
				case "C":
					createBankAccount();
					break;
				case "D":
					deleteBankAccount();
					break;
				case "E":
					moneyTransfer();
					break;
				case "F":
					printBankClientProfile();
					break;
				case "G":
					printBankClientBankAccounts();
					break;
				}
			}
		}
	}
	
	//Anthony - use case 3 - creates the profile of the bank client
	public void createBankClientProfile() {
		if(client.getFirstName() != null && client.getLastName() != null && client.getAge() == -1) {
			System.out.println("Error!");
		} else {
			System.out.println("Please enter first name: ");
			String fname = input.nextLine();
			if(fname == null) {
				System.out.println("Error!");
			} else {
				client.setFirstName(fname);
			}
			
			System.out.println("Please enter last name: ");
			String lname = input.nextLine();
			if(lname == null) {
				System.out.println("Error!");
			} else {
				client.setLastName(lname);
			}
			
			System.out.println("Please enter address: ");
			String address = input.nextLine();
			if(address == null) {
				System.out.println("Error!");
			} else {
				client.setAddress(address);
			}
			
			System.out.println("Please enter age: ");
			int age = input.nextInt();
			if(age < 0) {
				System.out.println("Error!");
			} else {
				client.setAge(age);
			}
			
			System.out.println("Profile successfully created!");
			
		}
	}
	
	//Ben - use case 4 - updating the profile of the bank client
	public void updateBankClientProfile() {
		System.out.println("1. Update Address");
		System.out.println("2. Update Age");
		System.out.println("3. Update Address and Age");
		System.out.println("Please enter your choice: ");
		int choice = input.nextInt(); 
		switch(choice) {
		case 1: 
			System.out.println("Please enter your address:");
			String newAddress = input.nextLine(); 
			if(newAddress == null ){
				System.out.println("Error!");
			}else {
				client.setAddress(newAddress);
				System.out.println("Address successfully updated.");
				} 
			break; 
		case 2:	
			System.out.println("Please enter your age:");
			int newAge = input.nextInt(); 
			if(newAge <0 ){
				System.out.println("Error!");
			}else {
				client.setAge(newAge);
				System.out.println("Age successfully updated.");
				} 
			break; 
		case 3: 
			System.out.println("Please enter your address:");
			String newAddress2 = input.nextLine(); 
			if(newAddress2 == null ){
				System.out.println("Error!");
			}else {
				client.setAddress(newAddress2);
				} 
			System.out.println("Please enter your age:");
			int newAge2 = input.nextInt(); 
			if(newAge2 <0 ){
				System.out.println("Error!");
			}else {
				client.setAge(newAge2);
				System.out.println("Address and Age successfully updated.");
				} 
			break;
			
		} 
	}
	
	//Ben - use case 5 - creating a bank account
	public void createBankAccount() {
		System.out.println("1 - Basic Account");
		System.out.println("2 - Premium Account");
		System.out.println("Please select what type of account you would like to create:");
		int choice = input.nextInt(); 
		switch(choice) { 
		case 1:
			BankAccount newAccount = new BankAccount(); 
			client.setBankAccount(newAccount);
			System.out.println("New Basic Account Successfully Created!");
			break;
		case 2:
			BankAccount newAccountPremium = new BankAccount();
			client.setBankAccount(newAccountPremium);
			newAccountPremium.setBalance(newAccountPremium.getBalance()-((PremiumBankAccount)newAccountPremium).getFee());
			System.out.println("New Premium Account Successfully Created!");
			break;
		}
		
	}
	
	//Ben - use case 6 - deleting a bank account
	public void deleteBankAccount() {
		System.out.println("Please input the ID of the account you would like to delete:");
		int accountID = input.nextInt(); 
		BankAccount[] clientAccounts = client.getBankAccounts(); 
		for(int i = 0; i>clientAccounts.length; i++) {
			BankAccount accountA = clientAccounts[i]; 
			if(accountA.getBankAccountId() != accountID) {
				System.out.println("Error!");
			}else {
				accountA = null; 
			}
		}

	}
	
	//Oisin - use case 7 - transferring money between bank accounts
	public void moneyTransfer() {	
		BankAccount sourceAccount = new BankAccount();
		BankAccount targetAccount = new BankAccount();
		BankClient clientTarget = new BankClient();
		
		System.out.println("Please enter the source bank account ID: ");
		int id = input.nextInt();
		boolean idExists = false;
		if(id < 0) {
			System.out.println("Error!");
		} else {
			if(id >=0 && id <=1000) {
				for(int i = 0; i < accounts.length; i++) {
					int idCheck = accounts[i].getBankAccountId();
					if(id == idCheck) {
						idExists = true;
						sourceAccount = accounts[i];
						
	}
				}
			}
		}		
		System.out.println("Please enter the target bank account ID: ");
		int tid = input.nextInt();
		boolean tidExists = false;
		if(tid < 0) {
			System.out.println("Error!");
		} else {
			if(tid >=0 && tid <=1000) {
				for(int i = 0; i < accounts.length; i++) {
					int tidCheck = accounts[i].getBankAccountId();
					if(tid == tidCheck) {
						tidExists = true;
						targetAccount = accounts[i];
		
					}
				}
			}
		}
		
		System.out.println("Please enter the bank account ID of the target bank client ");
		int cid = input.nextInt();
		boolean cidExists = false;
		if(id < 0) {
			System.out.println("Error!");
		}
		else {
			if(cid >=0 && cid <=1000) 
			{
				for(int i = 0; i < clients.length; i++) {
					int cidCheck = clients[i].getClientID();
					if(cid == cidCheck) {
						cidExists = true;
						clientTarget = clients[i];
					} 
				}
		
			}
		}
		System.out.println("Please enter the amount you would wish to transfer ");
		double cash = input.nextInt();
		double sourceCash = sourceAccount.getBalance();
		if(cash > sourceCash) {
			System.out.println("Error! Insufficent funds");
		}
		else {
			System.out.println("Transfer has been successful");
			cash = cash - sourceCash;
			sourceAccount.setBalance(sourceCash);
		}
						
	}
	
	//Oisin - use case 8 - printing the profile of a bank client
	public void printBankClientProfile() {
		System.out.println(client.getFirstName() + ", " + client.getLastName() + ", " + client.getAddress() + ", "  + client.getAge());
	}
	
	//Oisin - use case 9 - printing the bank accounts of a bank client
	public void printBankClientBankAccounts() {
		
		BankAccount[] clientAccounts = client.getBankAccounts();
		for(int i = 0; i < clientAccounts.length; i++) {
			BankAccount singleAccount = clientAccounts[i];
			if(singleAccount instanceof PremiumBankAccount) {
				System.out.println(singleAccount.getBankAccountId());
				System.out.println(((PremiumBankAccount) singleAccount).getFee());
				System.out.println(((PremiumBankAccount) singleAccount).getCashback());
			} else {
				System.out.println(singleAccount.getBankAccountId());
			}
		}
		
		/*
		System.out.println("Which type of bank account do you own? \n 1. Premium bank account \n 2. Basic Bank account");
		//Depending on what option the user chooses will decide what message will be displayed
		Scanner sc = new java.util.Scanner(System.in);
		byte choice = sc.nextByte();
		
		if(choice == 1) {
		
		System.out.println(account.bankAccountID + account.cashAmountFee + account.totalCashBack);
		}
		if(choice == 2) {
			System.out.println(account.bankAccountID);
		}

	}
	}
	*/
	}
}
